#pragma once

#include "CommonDef.h"

namespace hybridclr
{

	class Runtime
	{
	public:
		static void Initialize();
	};
}
#include "../Il2CppCompatibleDef.h"

namespace hybridclr
{
	const char* g_placeHolderAssemblies[] =
	{
		//!!!{{PLACE_HOLDER

		//!!!}}PLACE_HOLDER
		nullptr,
	};
}

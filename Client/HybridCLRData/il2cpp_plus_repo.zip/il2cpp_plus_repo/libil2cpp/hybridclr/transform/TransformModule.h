#pragma once

namespace hybridclr
{
namespace transform
{
	class TransformModule
	{
	public:
		static void Initialize();
	};
}
}
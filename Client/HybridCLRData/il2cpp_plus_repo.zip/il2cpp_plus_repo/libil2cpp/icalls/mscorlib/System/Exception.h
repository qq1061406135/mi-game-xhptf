#pragma once

namespace il2cpp
{
namespace icalls
{
namespace mscorlib
{
namespace System
{
    class LIBIL2CPP_CODEGEN_API Exception
    {
    public:
        static void ReportUnhandledException(Il2CppException* exception);
    };
} // namespace System
} // namespace mscorlib
} // namespace icalls
} // namespace il2cpp

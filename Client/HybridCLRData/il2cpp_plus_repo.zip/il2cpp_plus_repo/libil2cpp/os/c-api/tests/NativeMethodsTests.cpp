#if ENABLE_UNIT_TESTS

#include "UnitTest++.h"

SUITE(NativeMethods)
{
}

#endif // ENABLE_UNIT_TESTS
